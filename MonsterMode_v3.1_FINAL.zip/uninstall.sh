#!/system/bin/sh

LOG=/data/local/tmp/monster_mode.log

echo "[UNINSTALL] Monster Mode v3.1" >> $LOG

# Stop monitoring
if [ -f /data/local/tmp/monster_monitor.pid ]; then
    kill $(cat /data/local/tmp/monster_monitor.pid) 2>/dev/null
    rm /data/local/tmp/monster_monitor.pid
fi

# Restore settings
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu" ] && echo "schedutil" > "$cpu" 2>/dev/null
done

settings put global window_animation_scale 1.0 2>/dev/null
settings put global transition_animation_scale 1.0 2>/dev/null
settings put global animator_duration_scale 1.0 2>/dev/null

# Clean up
rm -f /data/local/tmp/monster_state
rm -f /sdcard/MonsterMode.txt

echo "[UNINSTALL] Completed" >> $LOG
