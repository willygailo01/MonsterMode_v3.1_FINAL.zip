#!/system/bin/sh

ui_print " "
ui_print "╔════════════════════════════════════╗"
ui_print "║  🔥 MONSTER MODE v3.1 🔥          ║"
ui_print "║  Gaming Booster Module             ║"
ui_print "╚════════════════════════════════════╝"
ui_print " "
ui_print "Author: RVS WG"
ui_print "Version: 3.1"
ui_print " "
ui_print "✅ Features:"
ui_print "  • Auto-run on boot"
ui_print "  • Max CPU/GPU performance"
ui_print "  • 165Hz refresh rate"
ui_print "  • Super touch speed"
ui_print "  • Universal chipset support"
ui_print "  • Auto notifications"
ui_print " "
ui_print "📱 Device: $(getprop ro.product.model)"
ui_print "📱 Android: $(getprop ro.build.version.release)"
ui_print " "
ui_print "⚙️ Installing..."

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

ui_print " "
ui_print "✅ Installation complete!"
ui_print " "
ui_print "🔥 REBOOT to activate Monster Mode!"
ui_print " "
