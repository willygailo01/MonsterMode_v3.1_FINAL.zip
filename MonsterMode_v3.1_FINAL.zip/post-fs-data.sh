#!/system/bin/sh
# Monster Mode - Early Boot

MODDIR=${0%/*}
LOG=/data/local/tmp/monster_mode.log

echo "[BOOT] Monster Mode early init" >> $LOG

# Create directories
mkdir -p /data/local/tmp 2>/dev/null
chmod 777 /data/local/tmp 2>/dev/null

# Enable all CPU cores
for cpu in /sys/devices/system/cpu/cpu*/online; do
    [ -f "$cpu" ] && echo "1" > "$cpu" 2>/dev/null
done

echo "[BOOT] Early init completed" >> $LOG
