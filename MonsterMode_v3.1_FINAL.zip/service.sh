#!/system/bin/sh
# Monster Mode Gaming Booster v3.1
# Auto-run | Max Performance | Universal Support
# Author: RVS WG

MODDIR=${0%/*}
LOG=/data/local/tmp/monster_mode.log
STATE=/data/local/tmp/monster_state

log() {
    echo "[$(date '+%H:%M:%S')] $1" >> $LOG
    echo "[$(date '+%H:%M:%S')] $1"
}

notify() {
    cmd notification post -S bigtext -t "🔥 Monster Mode" tag_mm "$1" 2>/dev/null &
    am broadcast -a android.intent.action.SHOW_TEXT --es text "$1" 2>/dev/null &
    echo "$1 - $(date '+%H:%M:%S')" > /sdcard/MonsterMode.txt
    log "Notification: $1"
}

log "========================================"
log "  MONSTER MODE v3.1 AUTO-STARTING"
log "========================================"

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done
sleep 15

log "Boot completed, starting optimizations..."

# Detect SoC
detect_soc() {
    local hw=$(getprop ro.hardware)
    local platform=$(getprop ro.board.platform)
    
    case "$hw:$platform" in
        *qcom*|*snapdragon*|*sm[0-9]*|*sdm*) echo "snapdragon" ;;
        *unisoc*|*sprd*) echo "unisoc" ;;
        *mt[0-9]*|*mediatek*) echo "mediatek" ;;
        *exynos*) echo "exynos" ;;
        *) echo "generic" ;;
    esac
}

SOC=$(detect_soc)
log "Device: $(getprop ro.product.model)"
log "SoC: $SOC"
log "Android: $(getprop ro.build.version.release)"

# Apply maximum performance
apply_performance() {
    log "🔥 Applying maximum performance..."
    
    # CPU Performance
    log "Optimizing CPU..."
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        [ -f "$cpu" ] && {
            echo "performance" > "$cpu" 2>/dev/null
            log "  $(basename $(dirname $cpu)): performance"
        }
    done
    
    # CPU Boost
    echo "1" > /sys/devices/system/cpu/cpufreq/boost 2>/dev/null
    echo "1" > /sys/module/cpu_boost/parameters/cpu_boost 2>/dev/null
    
    # GPU Performance
    log "Optimizing GPU..."
    case "$SOC" in
        snapdragon)
            if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
                echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
                echo "0" > /sys/class/kgsl/kgsl-3d0/throttling 2>/dev/null
                log "  Adreno GPU: performance mode"
            fi
            ;;
        *)
            for mali in /sys/class/misc/mali*/device/devfreq/*/governor \
                       /sys/devices/platform/*.mali/devfreq/*.mali/governor; do
                [ -f "$mali" ] && echo "performance" > "$mali" 2>/dev/null
            done
            log "  Mali GPU: performance mode"
            ;;
    esac
    
    # Display optimization
    log "Setting max refresh rate..."
    settings put system peak_refresh_rate 165 2>/dev/null
    settings put system min_refresh_rate 120 2>/dev/null
    setprop debug.sf.fps 165 2>/dev/null
    
    # Disable animations
    settings put global window_animation_scale 0 2>/dev/null
    settings put global transition_animation_scale 0 2>/dev/null
    settings put global animator_duration_scale 0 2>/dev/null
    log "  Animations disabled"
    
    # Touch optimization
    log "Optimizing touch response..."
    echo "1" > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
    
    # Network optimization
    log "Optimizing network..."
    echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    settings put global wifi_suspend_optimizations_enabled 0 2>/dev/null
    
    # Memory optimization
    log "Optimizing memory..."
    sync
    echo "3" > /proc/sys/vm/drop_caches 2>/dev/null
    echo "0" > /proc/sys/vm/swappiness 2>/dev/null
    am kill-all 2>/dev/null
    
    # Battery performance mode
    settings put global low_power 0 2>/dev/null
    
    # I/O optimization
    for sched in /sys/block/*/queue/scheduler; do
        [ -f "$sched" ] && {
            if grep -q "deadline" "$sched"; then
                echo "deadline" > "$sched" 2>/dev/null
            fi
        }
    done
    
    # Thermal management
    for thermal in /sys/class/thermal/thermal_zone*/mode; do
        [ -f "$thermal" ] && echo "disabled" > "$thermal" 2>/dev/null
    done
    
    echo "ON" > $STATE
    log "✅ MAXIMUM PERFORMANCE ACTIVATED!"
    notify "🔥 MONSTER MODE ACTIVATED ⚡ Max Performance!"
}

# Game detection
detect_game() {
    local app=$(dumpsys window windows 2>/dev/null | grep -oE "mCurrentFocus.*" | cut -d'/' -f1 | sed 's/.*{\s*//')
    
    case "$app" in
        *pubg*|*freefire*|*callofduty*|*mobilelegends*|*wildrift*|\
        *genshin*|*game*|*unity*|*unreal*) echo "$app" ;;
        *) echo "None" ;;
    esac
}

# Monitor games
monitor() {
    local last=""
    log "Starting game monitor..."
    
    while true; do
        local game=$(detect_game)
        
        if [ "$game" != "None" ] && [ "$game" != "$last" ]; then
            log "Game detected: $game"
            notify "🎮 Gaming: $game"
            apply_performance
            last="$game"
        fi
        
        sleep 3
    done
}

# Initial optimization
apply_performance

# Start monitoring
monitor &
echo $! > /data/local/tmp/monster_monitor.pid

log "Monster Mode running in background..."
